setwd("C:\\Users\\Lenovo\\Desktop\\IT24102671")

observed_counts <- c(120, 95, 85, 100)

chisq.test(x = observed_counts)

